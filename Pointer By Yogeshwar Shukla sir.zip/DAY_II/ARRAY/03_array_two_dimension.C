 #include <stdio.h> 
#include <stdlib.h>
#include <assert.h> 

typedef unsigned long long int u64; 

void method1(void); 
void method2(void); 
void method3(void); 
void method4(void);

int main(void)
{
    method1(); 
    method2(); 
    method3(); 
    return (0);    
}

void method1(void)
{
    int a[5][3]; 
    int i, j; 
    printf("address of a = %llu\n", (u64)a);
    printf("address of a + 1 = %llu\n", (u64)(a+1)); 
    printf("address of &a + 1 = %llu\n", (u64)(&a+1)); 

    puts("METHOD1:element is set to multiplication of its indices:"); 
    // set 
    for(i = 0; i < 5; ++i)
        for(j = 0; j < 3; ++j)
            a[i][j] = i * j; 

    // print 
    for(i = 0; i < 5; ++i)
        for(j = 0; j < 3; ++j)
            printf("a[%d][%d]:%d\n", i, j, a[i][j]); 
}

void method2(void)
{
    int m = 6, n = 4; 
    int i, j; 
    int* p = NULL; 
    int element; 

    p = (int*)malloc(sizeof(int) * m * n); 
    assert(p); 

    // set 
    for(i = 0; i < m; ++i)
        for(j = 0; j < n; ++j)
            *(p + i * n + j) = i + j; 

    // print 
    puts("METHOD2:element is set to addition of its indices:"); 

    for(i = 0; i < m; ++i)
        for(j = 0; j < n; ++j)
        {
            element = *(p + i * n + j); 
            printf("a[%d][%d]:%d\n", i, j, element); 
        }

    free(p); 
    p = NULL; 
}

void method3(void)
{
    int (*p)[6][4]; 
    typedef int (*array_t)[6][4]; 
    int i, j; 

    puts("METHOD3:element is set to multiplication of its indices:"); 

    p = (array_t)malloc(sizeof(int) * 6 * 4); 
    
    // set 
    for(i = 0; i < 6; ++i)
        for(j = 0; j < 4; ++j)
            (*p)[i][j] = i * j; 
            //*((*p) + i * 4 + j)  = i * j;  
    // print
    for(i = 0; i < 6; ++i)
        for(j = 0; j < 4; ++j)
            printf("a[%d][%d]:%d\n", i, j, (*p)[i][j]); 

    free(p); 
    p = NULL; 
}

void method4(void)
{
    int m = 6, n = 4; 
    int **pp = NULL; 
    int i, j; 

    pp = (int**)malloc(sizeof(int*) * m); 
    for(i = 0; i < m; ++i)
        pp[i] = (int*)malloc(n * sizeof(int)); 

    // set 
    for(i = 0; i < m; ++i)
        for(j = 0; j < n; ++j)
            pp[i][j] = i * j; 

    // print 
    for(i = 0; i < m; ++i)
        for(j = 0; j < n; ++j)
            printf("pp[%d][%d]:%d\n", i, j, pp[i][j]); 

    // free
    for(i = 0; i < m; ++i)
        free(pp[i]);

    free(pp);  
    pp = NULL; 
}

/* 
    int a[5][3]; 

    
    typeof(a) = int [5][3]; 

    sizeof(typeof(a)) = sizeof(int [5][3])
                      = sizeof(int) * 5 * 3 
                      = 4 * 5 * 3 
                      = 60 

    a + 1 = address of a + sizeof(a) 
          = 1008720739760 + 60 
            1008 7207 39 820 
    
    &a[0] 
    int     [3] 

    a + 1  = address of a + 12 
    int a   [5][3]

    int a[5][3]; 

    a = &a[0];

    a[5] -> int [3]

    a = &a[0]=element type size = 12 

    a + 1 

    address of a + size of type of array element 
    address of a + size of (int [3])
    address of a + sizeof(int) * 3 
    address of a + 12 

    int a[5][3]

    &a[0] = address of int [3]

    a + 1 = addre

    &a = int [5][3]
#------------------------------------------------------

int a[10]; // 40 

a + 1 : address of a + sizeof(int) 

&a + 1 : address of a + sizeof(int [10])
         address of a + sizeof(int) * 10 
         address of a + 40 


*/ 
