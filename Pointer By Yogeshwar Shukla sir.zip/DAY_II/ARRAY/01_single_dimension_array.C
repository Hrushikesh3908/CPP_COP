#include <stdio.h> 
#include <stdlib.h> 

int A[10]; 

int main(void)
{
    int i; 

    for(i = 0; i < 10; ++i)
        A[i] = (i+1) * 100; 

    int* pa = (int*)malloc(10 * sizeof(int)); 
    for(i = 0; i < 10; ++i)
        *(pa+i) = (i+1) * 100; 

    free(pa); 
    pa = NULL; 

    return (0); 
}