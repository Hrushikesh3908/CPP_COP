#include <stdio.h> 
#include <stdlib.h> 
#include <assert.h> 

typedef unsigned long long int u64; 

void method1(void); 
void method2(void); 

int main(void)
{
    method1(); 
    method2(); 
    return (0);  
}

void method1(void)
{
    int a[8]; 
    int i; 

    puts("Array Syntax:");
    for(i = 0; i < 8; ++i)
        printf("&a[%d]:%llu\n", i, (u64)&a[i]); 

    puts("Pointer syntax:"); 
    for(i = 0; i < 8; ++i)
        printf("(a + %d):%llu\n", i, (u64)(a+i)); 
}

void method2(void)
{
    int* p_array = NULL; 
    int i; 

    puts("method2:"); 
    p_array = (int*)malloc(8 * sizeof(int)); 
    assert(p_array); 

    puts("method2:"); 
    for(i = 0; i < 8; ++i)
        printf("(p_array + %d) = %llu\n", i, (u64)(p_array + i)); 

    free(p_array); 
    p_array = NULL; 
}







