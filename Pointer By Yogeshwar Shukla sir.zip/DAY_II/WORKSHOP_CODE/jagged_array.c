#ifndef size_t 
#define size_t unsigned long long int
#endif 

struct array{
    int* p; 
    size_t n; 
}; 

struct jagged_array
{
    struct array* p_array; 
    size_t jagged_array_size; 
}; 

struct jagged_array
{
    struct array
    {
        int* p;
        size_t n; 
    }*p_array; 
    size_t jagged_array_size; 
}; 