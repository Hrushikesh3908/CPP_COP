#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

void test_1(void); 
void test_2(void); 
void test_3(void); 
void test_4(void); 

int main(void) 
{
    test_1(); 
    test_2(); 
    test_3(); 
    test_4(); 
    return (0); 
}

void test_1(void)
{
    int* A[5]; 
    int i; 
    puts("test_1:"); 
    memset(A, 0, sizeof(A)); 

    for(i = 0; i < 5; ++i)
        A[i] = (int*)malloc(sizeof(int)); 

    for(i = 0; i < 5; ++i)
        *A[i] = (i+1) * 10; 

    for(i = 0; i < 5; ++i)
        printf("*A[%d]:%d\n", i, *A[i]); 

    for(i = 0; i < 5; ++i)
    {
        free(A[i]); 
        A[i] = NULL; 
    }
}
 
void test_2(void)
{
    int (*p)[5] = NULL; 
    int i; 
    puts("test_2:"); 
    p = (int(*)[5])malloc(5 * sizeof(int)); 
    for(i = 0; i < 5; ++i)
        (*p)[i] = (i+1) * 10; 
    for(i = 0; i < 5; ++i)
        printf("(*p)[%d]:%d\n", i, (*p)[i]); 

    free(p); 
    p = NULL; 
}

void test_3(void)
{
    int (*A[5])[5];     /* A:[   ][   ][   ][   ][   ]*/ 
    int i; 
    int j; 
    puts("test_3:"); 
    memset(A, 0, sizeof(A)); 
    
    for(i = 0; i < 5; ++i)
        A[i] = (int(*)[5])malloc(5 * sizeof(int)); 
    
    for(i = 0; i < 5; ++i)
        for(j = 0; j < 5; ++j)
            (*A[i])[j] = (i + j); 

    for(i = 0; i < 5; ++i)
        for(j = 0; j < 5; ++j)
            printf("(*A[%d])[%d]:%d\n", i, j, (*A[i])[j]); 

    for(i = 0; i < 5; ++i)
    {
        free(A[i]); 
        A[i] = NULL; 
    }
}

void test_4(void)
{
    int *A[5][5]; 
    int i, j; 
    puts("test_4:"); 
    for(i = 0; i < 5; ++i)
        for(j = 0; j < 5; ++j)
            A[i][j] = (int*)malloc(sizeof(int)); 

    for(i = 0; i < 5; ++i)
        for(j = 0; j < 5; ++j)
            *A[i][j] = (i + j) * 10; 

    for(i = 0; i < 5; ++i)
        for(j = 0; j < 5; ++j)
            printf("*A[%d][%d]:%d\n", i, j, *A[i][j]); 

    for(i = 0; i < 5; ++i)
        for(j = 0; j < 5; ++j)
        {
            free(A[i][j]); 
            A[i][j] = NULL; 
        }
 }