#include <stdio.h> 
#include <stdlib.h> 

int cpa_add(int x, int y); 
void sort(int* pa, int size); 
void show(int* pa, int size); 

int main(void)
{
    int ret; 
    int (*pfn1) (int, int); 
    
    ret = cpa_add(10, 20); 
    printf("ret = %d\n", ret); 

    pfn1 = cpa_add; 
    ret = pfn1(10,20); 
    printf("via:pfn1:pfn1(10,20)%:%d\n", ret); 

    return (0); 
}

int cpa_add(int x, int y)
{
    return (x+y); 
}

void sort(int* pa, int size)
{
    int i, j; 
    int key; 

    for(j = 1; j < size; ++j)
    {
        key = pa[j]; 
        i = j - 1; 
        while(i > -1 && pa[i] > key)
        {
            pa[i+1] = pa[i]; 
            i = i - 1; 
        }
        pa[i+1] = key; 
    }
}

void show(int* pa, int size)
{
    int i; 
    for(i = 0; i < size; ++i)
        printf("pa[%d]:%d\n", i, pa[i]);     
}