#include <stdio.h> 
#include <stdlib.h> 

int cpa_add(int x, int y); 
int cpa_sub(int x, int y); 
int cpa_mul(int x, int y); 
int cpa_div(int x, int y); 

int alu_operation(int (*pfn)(int, int), int arg1, int arg2)
{
    return pfn(arg1, arg2); 
}

int main(void)
{
    int choice; 
    int (*pfn_A[4])(int, int) = {cpa_add, cpa_sub, cpa_mul, cpa_div}; 

    printf("Select ALU OP:1->add, 2->sub, 3->mul, 4->div:"); 
    scanf("%d", &choice); 
    if(choice < 1 || choice > 4)
    {
        puts("bad choice"); 
        exit(-1); 
    }
    printf("ret = %d\n", alu_operation(pfn_A[choice-1], 20, 10)); 
    return (0); 
}

int cpa_add(int x, int y)
{
    return (x+y); 
}

int cpa_sub(int x, int y)
{
    return (x-y); 
}

int cpa_mul(int x, int y)
{
    return (x*y); 
}

int cpa_div(int x, int y)
{
    return x/y; 
}
