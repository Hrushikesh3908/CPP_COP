void insertion_sort(int* pa, int size); 

void insertion_sort(void* pa, int a_size, int size_of_element, int (*)(void*, void*))
{

}

int student_cmp1(struct student* p1, struct student* p2)
{
    if(p1->marks > p2->marks)
        return 1; 
    else if(p1->marks < p2->marks)
        return -1; 
    return (0); 
}


int student_cmp2(struct student* p1, struct student* p2)
{
    if(p1->roll > p2->roll)
        return 1; 
    else if(p1->roll< p2->roll)
        return -1; 
    return (0); 
}


insertion_sort(p_arr_students, 10, sizeof(struct student), COND  ? student_cmp1 : student_cmp2); 

int (*A_cmp_fn[])(struct student*, struct student*) = {cmp1, cmp2, ..., cmpn}; 
