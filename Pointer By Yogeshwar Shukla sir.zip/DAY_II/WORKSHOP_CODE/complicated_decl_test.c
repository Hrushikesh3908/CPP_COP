	#include <stdio.h> 

    int (*(*(*(*(*p)[3])(int, int))[4])(int, int))[5]; 

    int main(void)
    {
        puts("TEST PASSED"); 
        return (0); 
    }