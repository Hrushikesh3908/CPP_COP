Variable Name : 
    1] Built in     T v; 
    2] Structure    T v; 
#------------------------- 
    3] Array        A[] 
    4] Function     FUN()
    5] Pointer      *p

    int n; 
    struct A inA; 

    int A1[5]; 
    struct A  A2[5]; 

    int (*(*A[5])(int, int))[5]; 

#-----------------------------------------------------------

/* 
class A
{
    private: 
        int a;
        int b; 
        int c;
        mutable int cnt;    // const_cast is not required

    public: 
        int get_a() const
        {
            const_cast<A*>(this)->cnt = cnt + 1; // check if LHS is an lvalue
            return (a); 
        }
}; 
*/ 

Masterclass in C 
    
    Language 
    C -> assembly 
    DS & ALG 
    WIN & LINUX SYS PRO 
    WIN GUI WIN 32 SDK 
    Professioan Tools 

Masterclass in Python 
    ML | WEB | AUTOMATION 

Intermediate C 
    Masterclass in DS & ALG : avl tree, leftist, tournament, B/B+, RB, Radix, 

    Professional C++ : 98 / 11 / 14 : STL | Patterns | BOOST | Qt5

    coreprogrammingacademy@gmail.com 
    Subject :

1




