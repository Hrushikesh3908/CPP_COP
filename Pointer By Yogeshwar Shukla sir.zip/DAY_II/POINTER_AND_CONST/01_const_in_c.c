#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <assert.h> 

/* 
    Data definition statement in C global or local 
    can be qualified by keyword const. 

    Function declaration or definition cannot be 
    qualified by keyword const under C programming 
    language 
*/ 

const int gc_num = 100; 

int main(){
    const int lc_num = 200; 

    gc_num = 500;   /* Compile Time Error */ 
    lc_num = 400;   /* Compile TIme Error */ 



    return (0); 
}
