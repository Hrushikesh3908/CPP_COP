#include <stdio.h> 
#include <stdlib.h> 

const int gc_num = 100; 

int main(){
    const int lc_num = 1000; 
    int* p = NULL; 

    p = &lc_num;    /*  Warning: 
                        RHS type: const int* 
                        LHS type: int* 
                        Under C Programming language 
                        const int* is IMPLICITLY CONVERTIBLE 
                        to int* but this conversion is NOT desirable 
                        because it discards the constness of RVALUE
                        expression. C compiler emits a warning as such 
                    */ 
    
    printf("Before assignment:lc_num = %d\n", lc_num); 
    *p = 5000;      /* As address in p(=address of lc_num) is fundamentally from 
                        R/W area, at run time, deferencing p for writing will not 
                        result into GENERAL PROTECTION FAULT and therefore,
                        application will not be terminated abnormally 
                        (Just another example of how accessing memory via pointer 
                        can help you override language rules to access to that memory)
                    */ 
    printf("After assignment:lc_num = %d\n", lc_num); 

    p = &gc_num;    /*  Warning: 
                        RHS type: const int* 
                        LHS type: int* 
                        Under C Programming language 
                        const int* is IMPLICITLY CONVERTIBLE 
                        to int* but this conversion is NOT desirable 
                        because it discards the constness of RVALUE
                        expression. C compiler emits a warning as such 
                    */ 
    printf("Before assignment:gc_num = %d\n", gc_num); 
    
    *p = 5000;      /*  address in p = address of gc_num
                        It fundamentally comes from RONLY section. 
                        Therefore, any attempt to write on that address 
                        will be thwarted at run time by processor + OS combo. 

                        Processor will generate -> General Protection Fault (#GPF)
                        OS will deliver memory violation exception (in windows)
                        or segmentation fault (SIGSEGV signal) on X based systems 

                        and if unhandled the process terminates abnormally
                    */ 
    printf("After assignment:gc_num = %d\n", gc_num); /* will not get printed */ 

    return EXIT_SUCCESS; 
}