#include <stdio.h> 
#include <stdlib.h> 
#include <assert.h> 
#include <string.h> 
 
int m = 10; 

int *const const_ptr_non_const_int = &m; 

int main(){
    int n = 20; 

    // const_ptr_non_const_int = &n; 

  printf("Before:m=%d\n", m); 
    *const_ptr_non_const_int = 1000; 
    printf("After:m=%d\n", m); 

    return (0); 
}



//    const int* p;   /* pointer to const int */ 

//    int const *pc;  /* pointer tp const int */ 

//    int *const cp;  /* const pointer to int */  
