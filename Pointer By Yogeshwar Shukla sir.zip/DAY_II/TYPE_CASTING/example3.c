#include <stdio.h> 
#include <stdlib.h> 

typedef unsigned long long u64; 

struct A
{
    int a; 
    char b; 
    int c; 
}; 

int main(void)
{
    printf("OFFSET_OF:off_a = %llu, off_b = %llu, off_c = %llu\n", 
            (u64)(&((struct A*)0)->a),          
            (u64)(&((struct A*)0)->b)        
            (u64)(&((struct A*)0)->c)         
    ); 
        /*
        * 
        *       struct A* pa=&inA;
        * 
        *           1) pa+1 == address in pa + 1 * sizeof(strcut A)
                        =10000+1*sizeof(struct A)

               struct A* pa=  (struct A*)10000;
        *        
                            pa
        *           [     10000      ]
        *                43424234
        * 
                    2) inA.b
                       Base address of inA + offset(b)
                    
                    3) pa->b == (*pa)+offset(b)
                             =  (*43424234) + offset(b)
                             =  (10000) + offset(b)   
                             hence, pa->b means address in pa + offset(b)
                imp 4) (&((struct A*)0)->b)   

                    [ 0 ]
                     1111

                    correct case : 
                         (&0)->b == consider &0 is 1111
                         1111->b = (*1111) + offset(b)
                                 =  0 + offset(b) 
                                 
                    wrong case :
                           0->c= (*0) + offset(b)
                                   = but we cannot dereference 0 so its error
                                
             
        */


    /* 
    Base addr = 0 
    0->a    (0 + offset of a) -> R / W 
    0->b    (0 + offset of b) -> R / W 
    0->c    (0 + offset of c) -> R / W 

    0->c (*0).c 
    int* p = NULL;
 
    */ 

    return (0);  
}

/* 
    Android -> Linux -> DOUBLY CIRCULAR LINKED LIST 
    -> OFFSET_OF -> CONTAINER_OF
*/

/* 
  struct A inA; 

    u64 off_a, off_b, off_c; 

    off_a = (u64)&inA.a - (u64)&inA; 
    off_b = (u64)&inA.b - (u64)&inA;
    off_c = (u64)&inA.c - (u64)&inA; 

    printf("off_a = %llu, off_b = %llu, off_c = %llu\n", 
            off_a, off_b, off_c); 
*/ 