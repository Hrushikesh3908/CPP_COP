#include <stdio.h> 
#include <stdlib.h> 

int main(void)
{
    int n = 0x1a2b3c4d; 
    int i; 

    for(i = 0; i < 4; ++i)
        printf("byte number(%d):%llu\n", i+1, (unsigned long long)((char*)&n + i)); 

    for(i = 0; i < 4; ++i)
        printf("Content of byte number (%d) = %hhx\n", i+1, *(unsigned char*)((char*)&n + i)); 
    
    return (0); 
}
