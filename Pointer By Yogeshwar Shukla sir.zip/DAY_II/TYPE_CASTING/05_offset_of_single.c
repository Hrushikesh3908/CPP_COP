#include <stdio.h> 
#include <stdlib.h> 

struct A
{
    int a; 
    char b; 
    float c; 
}inA; 

/*  You are not allowed to create an instance of this structure 
    overtly or covertly 

    Yet, you are asked to compute the offset of a, b, c 
    with respect to base address of struct A's instance 

    struct T, member_name
*/ 

typedef unsigned long long int off_t; 

int main(void)
{
    /* Solution if instance creation were allowed */ 
    off_t offset_a, offset_b, offset_c; 

    offset_a = (off_t)&inA.a - (off_t)&inA; 
    offset_b = (off_t)&inA.b - (off_t)&inA; 
    offset_c = (off_t)&inA.c - (off_t)&inA; 

    printf("offset_a = %llu\noffset_b = %llu\noffset_c = %llu\n", 
            offset_a, offset_b, offset_c); 

    /* Solution w/o instance */ 
    struct A* p = NULL; 
    offset_a = offset_b = offset_c = 100; 
    offset_a = (off_t)(&p->a); /* type(&p->a) = int* */ 
    offset_b = (off_t)(&p->b); /* Type(&p->b) = char* */ 
    offset_c = (off_t)(&p->c); /* Type(&p->c) = float */
    
    printf("VIA SOLN 2:offset_a = %llu\noffset_b = %llu\noffset_c = %llu\n", 
            offset_a, offset_b, offset_c); 

    offset_a = (unsigned long long int)(&((struct A*)0)->a); 
    offset_b = (unsigned long long int)(&((struct A*)0)->b); 
    offset_c = (unsigned long long int)(&((struct A*)0)->c); 
    
    printf("VIA SOLN 3:offset_a = %llu\noffset_b = %llu\noffset_c = %llu\n", 
            offset_a, offset_b, offset_c); 

    return (0); 
}

/*
#define OFFSET_OF(Type,member)  ((unsigned long long int)(&((Type*)0) -> member))
*/ 

/*
void f()
{
    struct A * p = (struct A*)malloc(sizeof(int));  // 1000
    assert(p != NULL); 
    memset(p, 0, sizeof(struct A)); 

    p->a = 10;    
    p->b = 'A'; 
    p->c = 3.14f; 
}
*/ 

/* 
Container of 
Implicit Type Casting 

writing our own callback

callback function 
generic input 
generic output 

generic output : parameterized return value 

void* 
void** 

#----------------------------------------------------

pointer to string 
pointer to multi-dimensional 

struct bit field / union / enum / variadic functions 
volatile 
*/ 

/*
struct  A instA;
base address of inA + offset of(member) with resp to struct A;
*/