#include <stdio.h> 
#include <stdlib.h> 

/* 
    expr -> Ti 
          
    (Tc)expr

    OP((Tc)expr)

    Meaning of operating is decided as per Tc 
    But is applied on the value or memory location 
    depicted by expr. 

*/ 

int n = 0x0A0B0C0D; 
unsigned char uc; 

int main(void)
{
    uc = (unsigned char)n;
    printf("uc = %hhx\n", uc); 
    return (0); 
}
