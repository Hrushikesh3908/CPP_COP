#include <stdio.h> 
#include <stdlib.h> 

#define OFFSET_OF(Type, Mem) ((unsigned long long)(&(((Type*)0)->Mem)))

struct A
{
    int a; 
    char b; 
    float c; 
}; 

struct B
{
    char a; 
    int b; 
    char c; 
    int d; 
}; 

struct C
{
    char a, b; 
    int c, d; 
}; 

// (unsigned long long)(&c((struct A*)0)->c); 

int main(void)
{
    printf("OFFSET_OF(struct A, a) = %llu\n", OFFSET_OF(struct A, a)); 
    printf("OFFSET_OF(struct A, b) = %llu\n", OFFSET_OF(struct A, b));
    printf("OFFSET_OF(struct A, c) = %llu\n", OFFSET_OF(struct A, c));
    printf("OFFSET_OF(struct B, a) = %llu\n", OFFSET_OF(struct B, a));
    printf("OFFSET_OF(struct B, b) = %llu\n", OFFSET_OF(struct B, b));
    printf("OFFSET_OF(struct B, c) = %llu\n", OFFSET_OF(struct B, c)); 
    printf("OFFSET_OF(struct B, d) = %llu\n", OFFSET_OF(struct B, d));
    printf("OFFSET_OF(struct C, a) = %llu\n", OFFSET_OF(struct C, a));
    printf("OFFSET_OF(struct C, b) = %llu\n", OFFSET_OF(struct C, b));
    printf("OFFSET_OF(struct C, c) = %llu\n", OFFSET_OF(struct C, c));
    printf("OFFSET_OF(struct C, d) = %llu\n", OFFSET_OF(struct C, d));
    return (0); 
}


