#include <stdio.h> 
#include <stdlib.h> 

int* p = (int*)1000; 

int main(void)
{
    printf("p + 1 = %llu\n", (unsigned long long)(p + 1)); 
    printf("p + 1 = %llu\n", (unsigned long long)p + 1); 
    printf("p + 2 = %llu\n", (unsigned long long)(p + 2)); 
    printf("p - 1 = %llu\n", (unsigned long long)(p - 1));
    printf("p - 2 = %llu\n", (unsigned long long)(p - 2)); 

    printf("(char*)p + 1 = %llu\n", (unsigned long long)((char*)p + 1)); 
    printf("(char*)p + 2 = %llu\n", (unsigned long long)((char*)p + 2)); 
    printf("(char*)p - 1 = %llu\n", (unsigned long long)((char*)p - 1)); 
    printf("(char*)p - 2 = %llu\n", (unsigned long long)((char*)p - 2)); 

    return (0); 
}

o/p
p + 1 = 1004
p + 1 = 1001
p + 2 = 1008
p - 1 = 996
p - 2 = 992
(char*)p + 1 = 1001
(char*)p + 2 = 1002
(char*)p - 1 = 999
(char*)p - 2 = 998

