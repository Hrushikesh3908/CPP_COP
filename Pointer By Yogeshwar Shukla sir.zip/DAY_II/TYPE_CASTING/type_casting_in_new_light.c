#include <stdio.h> 
#include <stdlib.h> 

int n = 0x0a0b0c0d; 
unsigned char uc; 

int main(void)
{
    int n1 = 11, n2 = 4; 
    uc = (unsigned char)n; 
    float f; 
    f = n1/n2;  // idiv 2 
    f = ((float)n1)/n2;   // fdiv 
    return (0); 
}


