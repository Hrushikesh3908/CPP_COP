#include <stdio.h> 
#include <stdlib.h> 

 int main(void)
{
    int n = 0x0a0b0c0d; 

    if(*(char*)&n == 0xd)
        puts("This machine is a little endian machine"); 
    else if(*(char*)&n == 0xa)
        puts("This is a big endian machine"); 
    else
        puts("This is a strange machine"); 

    return 0; 
}

