#include <stdio.h> 
#include <stdlib.h> 

unsigned long long n = 0; 

/* 
    [   ][   ][   ][   ][   ][   ][   ][   ]
        7    6    5    4    3    2    1    x 
    Assignment 

    M[x] <- 0xFF 

    M[x + 1 : x + 2] <- 0 x FF FF 

    M[x + 3 : x + 6] <- 0x FF FF FF FF 

    M[x + 7] <- 0xFF 
*/ 

int main(void)
{
    printf("n = %llx\n", n); 
    
    *(char*)(&n) = 0xff; 
    printf("n = %llx\n", n);

    *(short*)((char*)(&n) + 1) = 0xffff; 
    printf("n = %llx\n", n);

    *(int*)((char*)&n + 3) = 0xffffffff; 
    printf("n = %llx\n", n);

    *(char*)((char*)&n + 7) = 0xff; 
    printf("n = %llx\n", n);

    return (0); 
}

