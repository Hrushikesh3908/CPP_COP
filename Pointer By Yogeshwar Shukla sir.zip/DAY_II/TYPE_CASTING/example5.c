#include <stdio.h> 
#include <stdlib.h> 

typedef unsigned long long u64; 

struct A
{
    char a; 
    int b; 
    float c; 
}; 

void show_1(int* p); 
void show_2(float* fp); 

int main(void)
{
    struct A* pA1 = (struct A*)malloc(sizeof(struct A)); 
    struct A* pA2 = (struct A*)malloc(sizeof(struct A)); 

    pA1->a = 'A'; 
    pA1->b = 100; 
    pA1->c = 3.14f; 

    pA2->a = 'Z'; 
    pA2->b = 200; 
    pA2->c = 6.28f; 

    show_1(&pA1->b); 
    show_2(&pA2->c); 

    free(pA1); 
    pA1 = NULL; 

    free(pA2); 
    pA2 = NULL; 
}

void show_1(int* p)
{
    u64 off_b = (u64)(&(((struct A*)0)->b)); 
    struct A* p_start = NULL; 

    p_start = (struct A*)((u64)p - off_b);  

    printf("show_1:p_start->a = %c\np_start->b=%d\np_start->c=%f\n", 
            p_start->a, p_start->b, p_start->c);

}

void show_2(float* fp)
{
    u64 off_c = (u64)(&(((struct A*)0)->c)); 
    struct A* p_start = (struct A*)((u64)fp - off_c); 

    printf("show_2:p_start->a = %c\np_start->b=%d\np_start->c=%f\n", 
            p_start->a, p_start->b, p_start->c);
}
