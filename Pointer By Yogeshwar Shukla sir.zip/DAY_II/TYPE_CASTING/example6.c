#define OFFSET_OF(Type, Mem)    ((unsigned long long)(&((Type*)0)->Mem))

#define CONTAINER_OF(addr, Type, Mem)   ((Type*)((unsigned long long)addr - OFFSET_OF(Type, Mem)))

struct A* p_start1 = CONTAINER_OF(p, struct A, b);
struct A* p_start2 = CONTAINER_OF(fp, struct A, c);