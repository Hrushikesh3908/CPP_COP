#include <stdio.h> 
#include <stdlib.h> 

int main(void)
{
    unsigned long long x = 0; 
    printf("1:x = %llx\n", x);
    *(unsigned char*)&x = 0xff; 
    printf("2:x = %llx\n", x); 
    *(unsigned short*)((char*)&x + 1) = 0xffff; 
    printf("3:x = %llx\n", x);
    *(unsigned int*)((char*)&x + 3) = 0xffffffff; 
    printf("4:x = %llx\n", x);
    *(unsigned char*)((char*)&x + 7) = 0xff; 
    printf("5:x = %llx\n", x);
    return (0); 
}

/* 
    [   ][  ][  ][  ][  ][  ][  ][  ]
1000      1   2   3   4   5   6   7

    &x = 1000 
    *(UC)1000 = cxff 

      [ff  ][ 0 ][0  ][0  ][ 0 ][0  ][ 0 ][0  ]
   1000      1   2   3   4   5   6   7

    0xff    0xff    0xff  0xff 0xff 0xff 0xff 
*/ 