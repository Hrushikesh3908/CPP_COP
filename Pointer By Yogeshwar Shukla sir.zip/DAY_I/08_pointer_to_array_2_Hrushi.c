#include<stdio.h>


void set_array(int (*p_array)[]);
void print_array(int (*p_array)[]);

int main(void)
{
    int A[5]={13,65,45,6,7};
    print_array(&A);
    printf("\n");
    set_array(&A);
     printf("\n");
    print_array(&A);
    return 0;
    
}
void set_array(int (*p_array)[])
{
    int i;
    printf("Set Array");
    for(i=0;i<5;i++)
    {
        (*p_array)[i]=(i+1)*10;
    }
}
void print_array(int (*p_array)[])
{
    int i;
    printf("Show Array ");
    for(i=0;i<5;i++)
    {
        printf("\t %d",(*p_array)[i]);
    }
}

/*
#include<stdio.h>

void set_array(int p_array[],int size);
void print_array(int (*p_array)[]);

int main(void)
{
    int A[5]={13,65,45,6,7};
    print_array(&A);
    printf("\n");
    set_array(A,5);
     printf("\n");
    print_array(&A);
    return 0;
    
}
void set_array(int p_array[],int size)
{
    int i;
    printf("Set Array");
    for(i=0;i<size;i++)
    {
        p_array[i]=(i+2)*10;
    }
}
void print_array(int (*p_array)[])
{
    int i;
    printf("Show Array ");
    for(i=0;i<5;i++)
    {
        printf("\t %d",(*p_array)[i]);
    }
}
*/