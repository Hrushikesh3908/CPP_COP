#include<stdio.h>

void set_array(int *arr,int size);
void print_array(int *arr, int size);

int main(void)
{
    int a[5]={0,0,0,0,0};
    print_array(a,5);
    set_array(a,5);
    printf("\n");
    print_array(a,5);
    return 0;
    
}
void set_array(int *arr,int size)
{
    int i;
    for(i=0;i<size;i++)
        *(arr+i)=(i+1)*10;
}
void print_array(int *arr, int size)
{
    int i;
    for(i=0;i<size;i++)
        printf("%d \t",*(arr+i));
}