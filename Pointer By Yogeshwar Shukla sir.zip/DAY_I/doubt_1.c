#include <stdio.h> 

void swap(int**, int**); 

int main(void)
{
    int m = 10, n = 20; 
    int* x = &m, *y = &n; 

    printf("BEFORE:m = %d, n = %d\n", m, n); 
    printf("BEFORE:*x = %d, *y = %d\n", *x, *y); 
    printf("x = %llu, y = %llu\n", (unsigned long long)x, (unsigned long long)y); 
    swap(&x, &y); 
    printf("AFTER:m = %d, n = %d\n", m, n); 
    printf("AFTER:*x = %d, *y = %d\n", *x, *y); 
    printf("x = %llu, y = %llu\n", (unsigned long long)x, (unsigned long long)y); 

    return (0); 
}

void swap(int** c, int** d)
{
    int* tmp; 
    tmp = *c; 
    *c = *d; 
    *d = tmp; 
}