#include <stdio.h> 

struct A{
    int a; 
    char b; 
    float c; 
}; 

struct B
{
    int a;  
    char b; 
    int c; 
    char d; 
}; 

struct C
{
    char a, c; 
    int b, d; 
}; 

struct D
{
    int a; 
    long long b; 
}; 

int main(void)
{
    printf("sizeof(struct A)=%llu\n", sizeof(struct A)); 
    printf("sizeof(struct B)=%llu\n", sizeof(struct B)); 
    printf("sizeof(struct C)=%llu\n", sizeof(struct C)); 
    printf("sizeof(struct D)=%llu\n", sizeof(struct D)); 
    return (0); 
}

