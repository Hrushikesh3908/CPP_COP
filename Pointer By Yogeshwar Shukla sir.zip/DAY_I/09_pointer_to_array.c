#include <stdio.h> 

void set_array(int* pa, int a_size); 
void print_array(int* pa, int a_size); 

int main(void)
{
    int a[5] = {0, 0, 0, 0, 0}; 

    print_array(a, 5); 
    set_array(a, 5); 
    print_array(a, 5); 

    return (0); 
}

void set_array(int* pa, int a_size)
{
    int i; 
    puts("Setting array"); 
    for(i = 0; i < a_size; ++i)
        *(pa + i) = (i + 1) * 10; 
    puts("Setting array complete");
}

void print_array(int* pa, int a_size)
{
    int i; 
    puts("Showing array:"); 
    for(i = 0; i < a_size; ++i)
        printf("pa[%d]:%d\n", i, pa[i]); 
}

