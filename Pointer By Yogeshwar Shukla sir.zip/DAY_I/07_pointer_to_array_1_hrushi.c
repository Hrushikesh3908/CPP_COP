#include<stdio.h>
int A[5]={12,33,43,32,3};
    int (*p)[5];
    
int main(void)
{
    int i;
    p=&A;
    //read
    for(i=0;i<5;i++)
        printf("%d \t",(*p)[i]);
        //write
    for(i=0;i<5;i++)
        (*p)[i]=(i+1)*10;
        
        //read
    printf("\n");
    for(i=0;i<5;i++)
        printf("%d \t",(*p)[i]);
    return 0;
}

/*
#include<stdio.h>

void fun1(int (*a)[]);

int main(void)
{
    int A[5]={12,33,43,32,3};
    int (*p)[5];

    p=&A;
    fun1(p);
    
    return 0;
}

    void fun1(int (*a)[])
    {
        //read
    int i;
    for(i=0;i<5;i++)
        printf("%d \t",(*a)[i]);
        //write
    for(i=0;i<5;i++)
        (*a)[i]=(i+1)*10;
        
        //read
    printf("\n");
    for(i=0;i<5;i++)
        printf("%d \t",(*a)[i]);
        
    }
    
*/