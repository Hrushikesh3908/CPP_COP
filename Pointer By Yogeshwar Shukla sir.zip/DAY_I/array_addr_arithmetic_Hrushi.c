#include<stdio.h>
int main(void)
{
    int n[5];
    char ch[5];
    float f[5];
    double d[5];
    int i;
printf("\n for integer");
for(i=0;i<5;i++)
printf("\n address of n[%d] is %llu",i,(unsigned long long ) (n+i) );

printf("\n for char");
for(i=0;i<5;i++)
printf("\n address of n[%d] is %llu",i,(unsigned long long ) (ch+i) );

printf("\n for float");
for(i=0;i<5;i++)
printf("\n address of n[%d] is %llu",i,(unsigned long long ) (f+i) );

printf("\n for float");
for(i=0;i<5;i++)
printf("\n address of n[%d] is %llu",i,(unsigned long long ) (d+i) );
     return 0;
     
}