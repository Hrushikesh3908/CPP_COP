#include <stdio.h> 

int n = 10; 
char c = 'A'; 
float f = 3.14f; 

float* pf; 
char* cp; 
int* p; 

void read(); 
void write(); 

int main()
{
    /* Addresses of six variables */
    printf  ("main:address of(n)=%llu, address of(c)=%llu, address of(f)=%llu\n", (unsigned long long)&n, 
                                                                             (unsigned long long)&c, 
                                                                             (unsigned long long)&f
            ); 

    printf ("main:address of(p)=%llu, address of(cp)=%llu, address of(pf)=%llu\n",   (unsigned long long)&p, 
                                                                                (unsigned long long)&cp, 
                                                                                (unsigned long long)&pf 
            ); 

    p = &n; 
    cp = &c; 
    pf = &f; 

    /* Address IN pointer variable */ 
    printf("main:address in(p)=%llu, address in(cp)=%llu, address in(pf)=%llu\n", (unsigned long long)p, 
                                                                             (unsigned long long)cp, 
                                                                             (unsigned long long)pf
            ); 

    read(); 
    write(); 

    return (0); 
}

void read()
{
    char c1; 
    int n1; 
    float f1; 

    c1 = *cp; 
    n1 = *p; 
    f1 = *pf; 

    printf("read:c1=%c, n1=%d, f1=%f\n", c1, n1, f1); 
}

void write()
{
    printf("write:c=%c, n=%d, f=%f\n", c, n, f); 
    *cp = 'Z'; 
    *p = 20; 
    *pf = 6.28f; 
    printf("write:c=%c, n=%d, f=%f\n", c, n, f); 
}