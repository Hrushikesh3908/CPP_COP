#include <stdio.h>
#include <stdlib.h> 

char ca[5]; 
int ia[5]; 
double da[5]; 

int i; 

int main(void)
{
    puts("Char array:"); 
    for(i = 0; i < 5; ++i)
        printf("ca + %d = %llu\n", i, (unsigned long long)(ca + i)); 

    puts("Integer array:"); 
    for(i = 0; i < 5; ++i)
        printf("ia + %d = %llu\n", i, (unsigned long long)(ia + i)); 

    puts("Double array:"); 
    for(i = 0; i < 5; ++i)
        printf("da + %d = %llu\n", i, (unsigned long long)(da + i)); 

    return (0); 

}

/* 

array_name + i = Base address of array + i * sizeof(typeof(array_element))
Let T be a data type. 
T A[N]; 
A + i where (0 <= i < N)
A[i] == *(A+i)
A + i   = Base address of A + i * sizeof(typeof(array_element))
        = Base Addr of A + i * sizeof(T)

int a[5][3]; 
int    a[5]    [3]
a[2] = a + 2 = base address of a + 2 * sizeof(typeof(array_element))
             = base address of a + 2 * sizeof(int [3])
             = base address of a + 2 * 3 * sizeof(int)
             = base address of a + 2 * 3 * 4 
             = base address of a + 24
    0     1   2 
0   [   ][  ][  ]
1   [   ][  ][  ]
2   [   ][  ][  ]
3   [   ][  ][  ]
4   [   ][  ][  ]
*/ 






