#include<stdio.h>
typedef int(*arr_t)[10]; 

int* p_int = (int*)1000; 
int (*p_arr)[10] = (arr_t)1000; 

int main(void)
{
    printf("p_int + 1 = %llu\n", (unsigned long long)(p_int+1)); 
    printf("p_arr + 1 = %llu\n", (unsigned long long)(p_arr+1));
    return (0);  
}