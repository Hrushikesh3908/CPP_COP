#include <stdio.h> 

void set_array(int (*p_array)[5]); 
void print_array(int (*p_array)[5]); 

int main(void)
{
    int A[5] = {0, 0, 0, 0, 0}; 

    print_array(&A); 
    set_array(&A); 
    print_array(&A); 

    return (0); 
}

void print_array(int (*p_array)[5])
{
    int i; 
    puts("Show array:");
    for(i = 0; i < 5; i++)
        printf("(*p_array)[%d]:%d\n", i, (*p_array)[i]); 
}

void set_array(int (*p_array)[5])
{
    int i; 
    puts("Setting array"); 
    for(i = 0; i < 5; ++i)
        (*p_array)[i] = (i+1) * 10; 
    puts("Setting array complete");
}
