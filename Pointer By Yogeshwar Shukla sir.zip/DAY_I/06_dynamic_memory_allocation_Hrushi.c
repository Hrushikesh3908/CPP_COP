#include <stdio.h> 
#include <stdlib.h> 

struct A
{

    int a; 
    char b; 
    // char x;
    int c;
    // char x;
};

void builtin_demo(); 
void array_demo(); 
void structure_demo(); 

void error(); 

int main()
{
    builtin_demo(); 
    array_demo(); 
    structure_demo(); 
    return (0); 
}

void builtin_demo()
{
    char* cp = NULL; 
    int* pi = NULL; 
    float* fp = NULL; 

    puts("BUILT IN DEMO:"); 
    /* allocate */ 
     printf("\naddress of cp is %llu \n ",(unsigned long long)cp);
    cp = (char*)malloc(sizeof(char)); 
    printf("\nAfter malloc memory allocation address of cp is %llu \n ",(unsigned long long)cp);
    if(cp == NULL)
        error(); 
    /* write */ 
    *cp = 'K'; 
    /* read */ 
    printf("*cp = %c\n" , *cp); 
    /* free */ 
    free(cp); 


    cp = NULL; 
    printf("\naddress of cp is %llu \n ",(unsigned long long)cp);

    /* allocate------------------ */ 
    printf("\naddress of pi is %llu \n ",(unsigned long long)pi);
    pi = (int*)malloc(sizeof(int)); 
    printf("\nAfter malloc memory allocation address of pi is %llu \n ",(unsigned long long)pi);

    if(pi == NULL)
        error();
    /* write */
    *pi = 500; 
    /* read */ 
    printf("*pi = %d\n", *pi); 
    /* free */ 
    free(pi); 
    pi = NULL; 
    printf("\naddress of pi is %llu \n ",(unsigned long long)pi);

    /* allocate */ 
    fp = (float*)malloc(sizeof(float)); 
    /* write */ 
    *fp = 500; 
    /* read */ 
    printf("*fp = %f\n", *fp); 
    /* free */ 
    free(fp); 
    fp = NULL; 
}

void array_demo()
{   
    int* pa = NULL; 
    int i; 

     puts("---------ARRAY DEMO:------------"); 
     
    printf("\n  Initailly pa  store  %llu ",(unsigned long long )pa); 
    /* allocate array of 5 integers */ 
    pa = (int*)malloc(5*sizeof(int)); //pa store staring add of 5 integer array
    printf("\n After malloc memory allocatuon pa  store  %llu ",(unsigned long long )pa);
    if(pa == NULL)
        error(); 
    
    /* write */ 
    for(i = 0; i < 5; ++i)
    {
        printf("\n Addres of pa[%d]= %llu",i,(unsigned long long)&pa[i]);
        pa[i] = (i+1) * 10; 
    }
    /* read */ 
    for(i = 0; i < 5; ++i)
        printf("\n pa[%d]:%d\n", i, pa[i]); 

    /* free */ 
    free(pa); 
    pa = NULL; 
}

void structure_demo()
{
    struct A* pA = NULL; 
    puts("-----------------STRUCTURE DEMO:-----------------"); 
    /* allocate */ 
    printf("pA strcuture pointer initally value is %llu \n",(unsigned long long)pA);
    pA = (struct A*)malloc(sizeof(struct A)); 
    printf("pA strcuture pointer After malloca memory allocation value is %llu \n",(unsigned long long)pA);
    printf("\n size of struct A is :%d \n"  ,sizeof(struct A));
    printf("pA->a : %llu \n",(unsigned long long)&pA->a);
    printf("pA->b : %llu \n",(unsigned long long)&pA->b);
    printf("pA->c : %llu \n",(unsigned long long)&pA->c);
    // printf("pA->x : %llu \n",(unsigned long long)&pA->x) ;   //uncommmend structure  char x;
    
    /* write */ 
    pA->a = 1000; 
    pA->b = 'M'; 
    pA->c = 2000;
    /* read */ 
    printf("pA->a=%d, pA->b=%c, pA->c=%d\n", pA->a, pA->b, pA->c); 


    /* free */ 
    free(pA); 
    pA = NULL;  
}

void error()
{
    printf("error in allocating memory...existing\n"); 
    exit(-1); 
}