#include<stdio.h>
   
    int a=10;
    char b='H';
    float c=3.14f;
    
    
    int *ip;
    char *ch;
    float *fp;
    
    void read();
    void write();       
    
int main()
{
 
    printf("\n The address of (a) is %llu , address of (b) is %llu , address of (c) is %llu ", (unsigned long long)&a ,(unsigned long long) &b,(unsigned long long )&c );
    printf("\n The address of ip is %llu, address of char pointer is %llu, address of float pointer is %llu", 
        (unsigned long long)&ip,(unsigned long long )&ch,(unsigned long long )&fp   );
    
    ip=&a;
    ch=&b;
    fp=&c;
    
    printf("\n The address of (ip) %llu , address of (ch) is %llu ,address of (fp) is %llu ",
    (unsigned long long) ip,(unsigned long long )ch,(unsigned long long )fp);
    
    read();
    write();
   return 0; 
}
void read()
{
    int x=*ip;
    char y=*ch;
    float z=*fp;
    printf("\n The value of x is %d, value of y is %c , value of z is %0.02f",x,y,z);
}
void write()
{
    printf("\n The value of x is %d, value of y is %c , value of z is %0.02f",a,b,c);
    *ip=20;
    *ch='M';
    *fp=312.332;
    printf("\n The value of x is %d, value of y is %c , value of z is %0.02f",a,b,c);

}