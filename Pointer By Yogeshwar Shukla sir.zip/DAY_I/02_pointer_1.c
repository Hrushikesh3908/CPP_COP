#include <stdio.h> 

void f(int* p); 

int main(void)
{
    int n = 100; 
    printf("n = %d\n", n); 
    f(&n); 
    printf("n = %d\n", n); 
    return (0); 
}

void f(int* p)
{
    *p = 200; 
}