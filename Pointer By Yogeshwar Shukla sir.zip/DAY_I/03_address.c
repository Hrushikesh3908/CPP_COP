#include <stdio.h> 


int main(void)
{
    int n = 100; 
    
    /* printing address in hexadecimal */ 
    printf("address(n)=&n=%p\n", &n); 

    /* printing address in integer */ 
    printf("address(n)=&n=%llu\n", (unsigned long long)&n); 

    return (0); 
}

/***************************************
SIGNED INTEGERS 
char -> 1 byte              %hhd    %hhx    %hho 
short -> 2 byte             %hd     %hx     %ho 
int -> 4 byte               %d      %x      %o 
long int -> 4 byte          %ld     %lx     %lo 
long long int -> 8 byte     %lld    %llx    %llo 
#---------------------------
UNSIGNED INTEGERS 
unsigned char - 1 byte              %hhu 
unsigned short 2 byte               %hu 
unsigned int -> 4 byte              %u 
unsigned long int -> 4 byte         %lu 
unsigned long long int -> 8 byte    %llu 
*/ 