#include <stdio.h> 

int A[5] = {10, 20, 30, 40, 50}; 
int (*p)[5];

int main(void)
{
    int i; 
    
    p = &A;

    for(i = 0; i < 5; ++i)
        (*p)[i] = (i+1) * 10; 

    for(i = 0; i < 5; ++i)
        printf("(*p)[%d]:%d\n", i, (*p)[i]);  

    return (0); 
}

/* 
    int n; 
    int* p; 
    p = &n; 
    *p = v; 
    v = *p; 

    void f(int* p)
    {

    }

    f(&n); 
---------------------------------------

    int A[5]; 
    int (*p)[5]; 

    p = &A; 

    (*p)[i] = v; 
    v = (*p)[i]; 
*/ 


